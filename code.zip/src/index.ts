import clock from './components/clock.svelte'
import stopWatch from './components/stopwatch.svelte'

export {
    clock,
    stopWatch
}